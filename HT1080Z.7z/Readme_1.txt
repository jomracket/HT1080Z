HT1080Z - VideoGenie-I/System-80/HT-1080Z emulator

� 2004-2011 Attila Gr�sz (gyros AT freemail DOT hu)
http://gaia.atilia.eu
http://ht.homeserver.hu


What's a HT-1080Z?
=================

The HT-1080Z was the second official school computer in Hungary.
Initial versions were unaltered VideoGenie-1 computers relabeled
and mounted with an on-board Yamaha/General Instruments AY-3-8910
sound chip. Later revisions had accented characters and modified
ROM contents. This Yamaha chip is the same one that appeared in
other famous computer models, such as the Amstrad and the Atari ST.

The current version of the emulator supports the unaltered HT1080Z
which is basically a VideoGenie with the Yamaha sound chip, along with
the BASIC ROM extension and the second series of HT1080Z's with some
of the extended characters of the Hungarian alphabet.

The VideoGenie (as marketed in Europe) and the System-80 (as marketed
in New Zealand and Australia) were in turn slightly modified clones
of the popular TRS-80 Model 1 Level II.


What's this thing I've just downloaded?
=======================================

Emulator, that imitates the behaviour of a piece of computer hardware
on another platform, in this specific case thus an 8-bit VideoGenie-1 is 
emulated on the Windows platform that is at the moment 32-bit.

Although a very good TRS-80 emulator exists that is in a great deal 
capable of emulating a VideoGenie as well, it has no specific support 
for this series and is also shareware.

HT1080Z is in turn freeware, and may be distributed freely if unaltered,
and the copyright notice is retained. As a consequence, the author take
no responsibilities whatsoever for any damage caused by this emulator. 
In short: use it at your own risk! 

HT1080Z also exploits the possibilities of a graphical user interface
with features such as drag'n'drop, intuitive menus etc.

New releases of the emulator will be published on the following page:
http://ht.homeserver.hu/html/emulatorletoltes.html


Features of the HT1080Z emulator
================================

- full and cycle exact Z80 CPU core
- support for VideoGenie-1/System-80 and the 1st and 2nd series of HT1080Z 
  computers
- support for 16 and 64 kb memory setups
- NMI interrupt (RESET)
- Video Cut (32 columns mode) and Page buttons
- 3 channel YM2149 sound chip emulation along with the noise and envelope 
  generators
- TRS-80 compatible tape sound
- full keyboard emulation
- direct loading of the disk based CMD format files
- read/write support for the CAS tape format
- WAV format support for tape output
- simple printer support
- Lowe LE15 High Resolution Graphic Adapter emulation


Missing features of the emulator
================================

- I/O port on the YM2149/AY-3-8910 sound board of the HT1080Z is not emulated
- the YM2149/AY-3-8910 emulation is not cycle exact
- joystick


Usage
=====


Running
-------

To be able to run this program, minimum Windows 95 is needed.
No install is necessary, just copy the contents of the ZIP package
to a new folder and click on the executable called HT1080Z.

The simplest way to get programs started is with drag'n'drop or via
the File->Autostart menu option. When drag'n'dropping a DSK file,
keeping the Ctrl key down will reboot the emulated machine.


Command line options
--------------------

General format:

HT1080Z.EXE [/a] [/d] [/g] [/h] [/i filename] [/m] [/r] [/w] [filename]

For now, only a few command line switches are supported:

/a        : suppress autostart of CAS and CMD images
/d        : enable double scan of screen lines
/g        : Lowe LE15 High Resolution Graphic Adapter emulation
/h        : disables sound at startup (by default it's on)
/i        : insert diskimage on startup into drive:0
/m        : specify HT model (1, 2 or 3)
/r        : specify RAM size (16 or 48)
/w        : run the emulator with the maximum speed possible


Monitor
-------

The program has a simple built-in monitor/disassembler. By pressing
ESC[-APE] can this be entered. On pressing this button again, one
can return to the emulated machine. Further keyboard shortcuts:

F1        : Disassembly list from the actual value of the IP.
            On top of the page, the current state of the CPU is shown.
F2        : Memory map of the emulated machine
F4        : Set breakpoint at actual position
F5        : Switch to emulator screen when in monitor
F7        : Run until here (if possible within a given amount of cycles)
ENTER     : Step one assembly instruction
PAGE UP   : One page up in the list
PAGE DOWN : One page down in the list
UP-ARROW  : One row upwards in the list
DOWN-ARROW: One row downwards in the list


Drive
-----

Full drive and WD1771 disk controller emulation is available. Image
support is restricted to DSK images (also known as JV1 and JV3) for
now.

Any DOS that is supported on a TRS-80 Model I should work well in
the emulator, among others: TRSDOS and NewDOS.

The /i command line option can be used to attach a boot disk image
on startup, so that the emulator will boot up in DOS mode.
Holding the BREAK key (TAB in the emulator) down on startup however 
will enforce booting into normal BASIC mode.

If a disk image has been altered, the user will be prompted upon 
detaching it, or exiting the emulator whether the changes should be
saved or not.

At the moment disk drive support is not very robust, so do not
use ot for important stuff. The emulator is somewhat fussy about
the disk images too: it will only accept perfectly aligned 89.600, 
102.400 and 204.800 bytes long files as valid JV1 or 98.304, 111.104 
and 213.504 bytes long files as valid JV3 images (35, 40 and 80 
sectors respectively).


Tape
----

This was the most widespread and thus most important peripheral of
the VideGenie as it was built-in to the computer case.

Two major formats exist for tape emulation: CAS and WAV. Latter is
at the moment write-only, the former is read and writeable.

- WAV

This format can be used if one would like to transfer a program to 
the real machine. The result can be then played back via the sound
output of the PC to a tape and reloaded on the real machine.

For creating such WAV, one has to first choose 'Create WAV' from the
Tape menu, press PLAY/RECORD by selecting the appropriate menu point from
the Tape menu and issuing the necessary commands in the emulated machine 
(for example: CSAVE"NAME"). The saving process is done realtime (=slow)
but the process can be accelerated by pressing ALT+F3 that gives full
CPU power to the emulator on your machine. It is important that once the
save command has finished the tape must be stopped (via the Tape menu, by
ticking PLAY/RECORD off) and the WAV should be closed (very important!).

Just like the TRS-80 Model I Level 2, the VideoGenie-1 also used a 500 baud
tape recording frequency.

- CAS

Quicker and more efficient format, widespread in the TRS-80 world. It
is a literal byte-exact representation of what is written to a real tape
on a real TRS-80/VideoGenie-1/System-80/HT1080Z.

Saving/loading of CAS files is done via ROM traps and hence it is 
not supporting custom loaders, but in return it is much quicker. Most
load and save operations finish in a snap. BASIC programs can be saved
with the CSAVE"N" command, in this case a pop-up window will appear where
you must fill in the name and location of the desired CAS image.

Saving a given memory location in CAS format is also possible via the file
menu. Here you must fill in the begin and the end of the memory area that is
about to be saved along with the start address which defaults to 0066h which
is the NMI entry point (RESET).

BASIC extension
---------------

The emulator comes with support for the BASIC ROM extension and the machine
code monitor. To enter the extended mode, one should type

>SYSTEM

*? /12288

into the emulator. For a full list of possibilities, see the relevant PDF
documentation available on Terry Stewart's System 80 page.


Thanks
======

* Istv�n Majzik, HT1080Z ROM dumps, tips, testing
* J�zsef L�szl�, webspace
* Viktor Varga, homepage
* Terry Stewart, for linking the emulator's page to his great System-80 site
* Zolt�n Koll�r, help with disk controller emulation, testing


Links
=====

Terry Stewart's System 80 resource site:
http://www.classic-computers.org.nz/system-80/

Hungarian VideoGenie/System-80/HT-1080Z tribute website 
(for now, mostly Hungarian only)
http://ht.homeserver.hu

Ira Goldklang's TRS-80 website:
http://www.trs-80.com


Changelog
=========

v1.6.4
------

- return correct port values when PC-joystick is not present
- turn off dynamic sound buffering when recording video

v1.6.3
------

- PC-joystick and gamepad support
- improved Centronics printer support
- fixing breakpoint support in the external monitor

v1.6.2
------

- custom screen refresh frequencies (between 5 and 200)
- copy screen contents to the clipboard (text format)
- better AY-3-8910 sound IC emulation (mixer)
- bugfixes (reenabled breakpoints)

v1.6.1
------

- custom cpu frequencies
- bugfixes (CAS traps, ROM handling, character generator, monitor)

v1.6
----

- ability to use custom ROMs
- bugfixes

v1.5
----

- added emulation of the TRS-80 Model 1 Level II
- save emulator output to AVI video
- save screenshot in GIF format (when non 1-bit display)
- a new, large anamorph screen mode (768x576)
- AY-3-8910 (YM2149) noise generator and frequency bug fixed
- Lowe LE18 split screen mode bug fixed

v1.4
-----

- Lowe LE15 High Resolution Graphic Adapter emulation
- correct screen aspect ratio
- paste text from the clipboard
- composite TV blur
- settings are now saved in the registry
- bugfixes (charset, video RAM etc.)

v1.3
-----

- full drive and WD1771 disk controller emulation
- support for tokenized /BAS images
- support for non-byte aligned CAS images
- fullscreen mode
- support for HT model 3
- new machine configuration dialog window
- many bugfixes

v1.2
----

- drag'n'drop support
- support for command line options
- double scan
- autostart emulator images (great for novice users)
- README in English
- graphic charset bug fixed
- YM2149 envelope bug fixed

v1.1
----

- simulated keyboard input from external text files (BAS/TXT)
- almost full YM2149 sound chip emulation
- Video Cut (32 column mode) and Page buttons
- better CAS tape format support
- improved charset for the VideoGenie-1
- 48 kb RAM suuport, selectable RAM size
- support for the second series of HT1080Z (different ROM from VideoGenie)

v1.0
-----

- CAS format support (R/W)
- saving in WAV format
- new icons

without version nr.
-------------------

- first public release
